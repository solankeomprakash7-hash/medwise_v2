# ARCHITECTURE — how MedWise is built

> Claude Code: keep this file up to date whenever structure changes. Explain changes to me in plain words.

## In one picture
```
Clinician (phone/desktop) ──► MedWise server (Vercel) ──► Result screen ──► Accept / Modify / Override
                                │                                                │
                                ├─ 1. Rules engine (no AI)                       │
                                ├─ 2. AI layer (Claude API) — picks + explains   │
                                └─ 3. Safety check                               │
                                │                                                ▼
                                └──── reads ◄── Database (Supabase, India region) ◄── saves decision
                                             knowledge base · antibiograms · cases · decisions
Stewardship admin ──► uploads antibiogram, views reports
```

## Tools
| Part | Tool | Why |
| --- | --- | --- |
| Website + server | Next.js (TypeScript) | One project for screens and server code |
| Styling | Tailwind CSS with tokens from `DESIGN.md` | Consistent look |
| Login, database, file storage | Supabase (India region) | Simple, secure, row-level security |
| AI | Claude API (paid, server-side only) | Paid usage is not used for model training |
| Hosting | Vercel: `staging` and `production` | Test before going live |
| Code history | GitHub | Every change is recorded |

## Folder layout (planned)
```
/app                 screens (entry, result, admin, login)
/app/api             server routes (recommend, decision, upload)
/lib/rules           rules engine: mdr-risk, regimen-filter, dosing, safety
/lib/ai              Claude call, prompt, JSON checking
/knowledge           signed-off CSV tables + VERSION file
/tests               golden test set runner
/docs                PRODUCT, CLINICAL_RULES, DESIGN, ARCHITECTURE, DECISIONS
CLAUDE.md
```

## Recommendation flow
1. Browser sends the form inputs to `/api/recommend`. **No identifiers** are sent.
2. Server validates inputs; missing required field → error.
3. **Rules engine** reads the knowledge base + this hospital's antibiogram and returns:
   MDR tier per organism, shortlist of allowed regimens, renal-adjusted doses, flags.
4. **AI layer** gets a patient summary + shortlist → returns JSON (`choice_id`, reasoning, refs, flags).
5. **Safety check**: choice on shortlist? JSON valid? If not, use rules' first choice + flag.
6. Server adds doses from `drugs.csv`, versions, disclaimers → sends result.
7. Case (de-identified) + result saved. Clinician's decision saved via `/api/decision`.

## Database tables (planned)
| Table | Holds |
| --- | --- |
| `hospitals` | name, settings (cut-off %, min isolates) |
| `users` | email, hospital_id, role (clinician / admin / owner) |
| `kb_versions` | version, uploaded_at, signed_off_by, files |
| `antibiograms` | hospital_id, year, unit, rows |
| `cases` | hospital_id, user_id, inputs (no identifiers), result, kb_version, model, created_at |
| `decisions` | case_id, action (accept / modify / override), final_regimen, reason, created_at |

Row-level security: users can only read and write rows of their own hospital.

## Secrets
API keys only in Vercel and Supabase environment settings. Never in code, never in the browser,
never in GitHub.

## Release rule
`staging` first → run golden tests → I check on my phone → then `production`.
